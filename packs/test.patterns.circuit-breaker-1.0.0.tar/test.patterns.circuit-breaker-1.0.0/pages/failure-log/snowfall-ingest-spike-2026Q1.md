# Failure: Ingest spike during 2026-Q1 snowfall event

## What broke
Border control ingest pipeline queued 40k events over 18 minutes.
Three downstream verification APIs became unreachable. Dashboard
showed queue depth climbing linearly with no relief.

## Root cause
Exponential backoff retry logic (5 attempts, 2× multiplier) turned
every timed-out API call into 5 queued retries. Under sustained load
this multiplied in-flight requests 5×, exceeding downstream capacity.
The retry storm was self-reinforcing: more failures → more retries →
more failures.

## What we changed
Removed retry from the ingest path entirely. Replaced with circuit
breaker pattern (see decisions/use-circuit-breaker-over-retry.md).
Added queue depth alerting at 5k (was previously unmonitored).
Added downstream API health checks to the ops dashboard.

## Result
Next spike (2026-Q2 test) hit the circuit breaker at 12 failures,
opened within 2s, queue stabilised at 800. Downstream APIs unaffected.
