# Distributed Systems Patterns KB
domain: distributed-systems

This knowledge base captures operational patterns and failure
experience from production distributed systems work. Focus areas:
resilience patterns, ingest pipeline stability, API boundary design,
and incident-derived architectural decisions. All decisions/ entries
reference real incidents. All failure-log/ entries include a "what
changed" section.
Entries are derived from real production incidents and reviewed
before publication.
