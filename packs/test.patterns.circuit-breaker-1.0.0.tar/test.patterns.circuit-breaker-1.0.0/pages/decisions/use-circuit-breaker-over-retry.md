# ADR: Circuit Breaker over Retry with Backoff
domain: distributed-systems

## Context
Our ingest pipeline calls three downstream APIs. Under load spikes
those APIs occasionally time out. We had exponential backoff + retry
(max 5 attempts, 2× backoff). During the 2026-Q1 snowfall incident
the retries amplified the spike — each timed-out request spawned 5
more. Queue depth hit 40k. Three downstream services fell over.

## Options considered
1. Retry with backoff (current) — simple, well-understood, amplifies load
2. Circuit breaker (Hystrix-style) — trips after N failures, fast-fails
   until probe succeeds, isolates callers from cascade
3. Bulkhead + retry — isolates by caller, adds operational complexity

## Decision
Adopted circuit breaker (option 2) via our internal resilience library.
Threshold: 5 failures in 10s opens the circuit. Half-open probe every 30s.
Retry removed entirely from the ingest path.

## Consequences
Positive: downstream services recovered within 90s of circuit opening.
Negative: callers now receive fast 503s during open-circuit windows —
requires client-side handling we hadn't needed before.
Trade-off accepted: predictable fast failure beats unpredictable cascade.
